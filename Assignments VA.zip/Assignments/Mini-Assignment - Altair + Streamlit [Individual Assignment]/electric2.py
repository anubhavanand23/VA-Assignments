import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import altair as alt

@st.cache
def load_data():
    df = pd.read_csv('daily_electricity.csv', index_col='Date')
    return df

st.title('Electricity Production by Source')

# load the data
df = load_data()

# show the data in a table
if st.sidebar.checkbox('Show dataframe'):
    st.write(df)

    

    
# choose the sources of interest
cols = ['Coal_MW', 'Gas_MW', 'Hidroelectric_MW', 'Nuclear_MW', 'Wind_MW', 'Solar_MW', 'Biomass_MW']
option = st.multiselect('What sources do you want to display?', cols, cols[0])



# MINI-HMW
# TODO - replace the Streamlit line_chart with the Altair multi line chart
#        used in the Demo to showcase the fold transformation


df = df.reset_index()


if st.sidebar.checkbox('Show Altair Multi line Chart'):
    mul_line_chart = alt.Chart(df).mark_line().transform_fold(option,).mark_line().encode(x='Date:T', y=alt.Y('value:Q', title='MW'),color='key:N').properties(
    title='Electricity Production',
    width=600,
    height=400
    ).interactive()
    st.write(mul_line_chart)

    
else:
    fig, ax = plt.subplots()
    df[option].plot(ax=ax)
    st.write( fig )   
    

 


    