from pycaret.datasets import get_data
import altair as alt
import streamlit as st
from pycaret.classification import *

# @st.cache
def return_pca_dataset():
    # get data   
    df_data = get_data('satellite')

    # model   
    clf = setup(data = df_data, target = 'Class', 
                       data_split_shuffle=False, 
                       pca=True,
                       silent=True, verbose=False)

    # train logistic regression model
    lr = create_model('lr', verbose=False)

    # predictions & data preparation for visualization
    #predictions = predict_model(lr, verbose=False)
    X_test = [l[1] for c in clf if type(c) == list for l in c if type(l) == tuple if 'X_test Set' == l[0]][0]
    y_test = [l[1] for c in clf if type(c) == list for l in c if type(l) == tuple if 'y_test Set' == l[0]][0]
    predictions = X_test.copy()                            # this is the transformed X_test
    predictions['Label'] = lr.predict(predictions.values)         # this is my prediction
    predictions['Class'] = y_test.copy()                          # this is the actual target
    
    predictions['Error'] = predictions['Class'].astype(str) != predictions['Label'].astype(str)

    return predictions

# get data for visualization
pred_pca = return_pca_dataset()



# Show 

x_axis_sidebar = st.sidebar.selectbox("X-axis" , pred_pca.columns[:14])
y_axis_sidebar = st.sidebar.selectbox("Y-axis" , pred_pca.columns[:14])

# altair plot
ch_pca = alt.Chart(pred_pca).mark_point().encode(
           x = x_axis_sidebar,
           y = y_axis_sidebar,
           color = 'Class:N',
           size = 'Error:N', 
           tooltip = ['Class', 'Label']
).properties(
    width=800,
    height=600
).interactive()

st.write(ch_pca)