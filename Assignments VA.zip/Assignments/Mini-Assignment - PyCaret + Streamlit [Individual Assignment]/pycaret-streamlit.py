import streamlit as st
import pandas as pd
from pycaret.regression import *

# load model
st.set_page_config(layout="wide")

column1,column2 =  st.columns(2)

@st.cache 
def predict_cache(test_data):
    rf_saved = load_model('rf_model')
    predictions = predict_model(rf_saved, data = test_data)
    return predictions['Label']


def func1():
# Inputs
    inp_sex = st.radio('Sex 1', ('female', 'male'), index=0)
    inp_smoker = st.radio('Smoker 1', ('no', 'yes'), index=0)
    inp_region = st.radio('Region 1', ('southeast', 'southwest', 'northeast', 'northwest'), index=0)
    inp_age = st.slider('Age 1', 18, 64, 35, step=1)
    inp_bmi = st.slider('BMI 1', 15.0, 54.0, 21.0, step=0.1)
    inp_children = st.slider('Children 1', 0, 5, 0, step=1)

    test_data = pd.DataFrame({'age': [inp_age], 
              'sex': [inp_sex], 
              'bmi': [inp_bmi], 
              'children' : [inp_children], 
              'smoker': [inp_smoker], 
              'region': [inp_region]})

# Show prediction
    st.write('Insurance charges = $%0.2f'%predict_cache(test_data)[0])
    
def func2():
# Inputs
    inp_sex_c2 = st.radio('Sex 2', ('female', 'male'), index=0)
    inp_smoker_c2 = st.radio('Smoker 2', ('no', 'yes'), index=0)
    inp_region_c2 = st.radio('Region 2' , ('southeast', 'southwest', 'northeast', 'northwest'), index=0)
    inp_age_c2 = st.slider('Age 2', 18, 64, 35, step=1)
    inp_bmi_c2 = st.slider('BMI 2', 15.0, 54.0, 21.0, step=0.1)
    inp_children_c2 = st.slider('Children 2', 0, 5, 0, step=1)

    test_data_c2 = pd.DataFrame({'age': [inp_age_c2], 
              'sex': [inp_sex_c2], 
              'bmi': [inp_bmi_c2], 
              'children' : [inp_children_c2], 
              'smoker': [inp_smoker_c2], 
              'region': [inp_region_c2]})

# Show prediction
    st.write('Insurance charges = $%0.2f'%predict_cache(test_data_c2)[0])
    
    
column1.header("Individual 1")
column2.header("Individual 2")

with column1:
    func1()
   
with column2:
    func2()
    


