

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import altair as alt
from bokeh.plotting import figure
import plotly.express as px

@st.cache
def load_data():
    df = pd.read_csv('losses2015_transformed.csv')
    return df
    
st.title("HMW#2 - Data & Task Abstraction. Streamlit [Group Assignment]")


#df1 = load_data()
df2 = pd.read_csv('losses2015_transformed.csv')
df1 = pd.DataFrame(df2)


#Checkbox to display data
if st.sidebar.checkbox("Show DataFrame Losses 2015_Transformed"):
    st.write(df1)
    

##Number of items and fields/attributes

st.write("Number of items = ", len(df1))


if st.sidebar.checkbox("Show Highest Amount for Damages"):
    # df = df1['State_Code'].value_counts()
    st.title('State with highest amount of damages')
    # st.bar_chart(data = df, width=600, height=500)
    # x = df1['State_Abv'].
    # y = df1['Amount'].values.tolist()
    fig = px.scatter(df1,
                x=df1['State_Abv'],
                y=df1['Amount'],
                title=f'State with highest amount of damages')
    st.plotly_chart(fig)                

    
if st.sidebar.checkbox("Show No of Damages per state"):
    df2= df1['State_Abv'].value_counts()
    st.title("State wise number of damages")
    st.bar_chart(df2,width=400, height=400)



if st.sidebar.checkbox("Show Maximum No of Damages"):
    df = df1['Damage_Descp'].value_counts()
    st.title('State with highest and lowest number of damages')
    st.bar_chart(data = df, width=600, height=500)


