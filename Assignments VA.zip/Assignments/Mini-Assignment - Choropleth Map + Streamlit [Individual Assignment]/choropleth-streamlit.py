import altair as alt
import pandas as pd
import numpy as np
from vega_datasets import data
import streamlit as st

# Data Sources
counties = alt.topo_feature(data.us_10m.url, 'counties')
source = data.unemployment.url


# counties
# id     geometry_fields
# 1000   Polygon

alt.Chart(counties).mark_geoshape(stroke='white').encode(
    tooltip=['id:O']
).project(
    type='albersUsa'
).properties(
    width=600,
    height=400
)

read_data = pd.read_csv(source, delimiter='\t')

#1. Create a pandas data frame called df_rates from the unemployment data source in the Jupyter notebook.

df_rates = pd.DataFrame(read_data)


#2. Add a new field to the data frame called rate_emp and set its values equal to 1 - rate.

df_rates['rate_emp'] = 1- df_rates['rate']

#df_rates.head(10)

#3. Create a Streamlit radio button to choose between rate and rate_emp.

st.title('Please select from below available options')
radio_button_names = ['rate', 'rate_emp']
selected_radio = st.radio('What do you want to show?' , radio_button_names, index=1)

#4. Based on the radio button option show a choropleth map for either the unemployment or employment rate.

if selected_radio == 'rate':
    ch_map_rate = alt.Chart(counties).mark_geoshape().encode(
    color='rate:Q',
    tooltip=['id:O', 'rate:Q']
    ).transform_lookup(
    lookup='id',
    from_=alt.LookupData(source, 'id', ['rate'])
    ).project(
    type='albersUsa'
    ).properties(title = 'Unemployment Rate',
    width=600,
    height=400
    )
    st.write(ch_map_rate)
    
elif selected_radio == 'rate_emp':
    ch_map_rate_emp = alt.Chart(counties).mark_geoshape().encode(
    color='rate_emp:Q',
    tooltip=['id:O', 'rate_emp:Q']
    ).transform_lookup(
    lookup='id',
    from_=alt.LookupData(df_rates, 'id', ['rate_emp'])
    ).project(
    type='albersUsa'
    ).properties(
    title = 'Employment Rate',
    width=600,
    height=400
    )
    st.write(ch_map_rate_emp)

# Transform Lookup
# https://altair-viz.github.io/user_guide/transform/lookup.html