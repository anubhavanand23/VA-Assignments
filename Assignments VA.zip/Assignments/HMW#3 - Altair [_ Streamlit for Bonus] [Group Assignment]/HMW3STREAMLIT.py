import pandas as pd
import numpy as np
import matplotlib as mp
import matplotlib.pyplot as plt
import altair as alt
from vega_datasets import data
import streamlit as st

read_file = pd.read_csv('losses2015_transformed.csv')
df = pd.DataFrame(read_file)

df2 = pd.DataFrame(data = df,columns = ['State_Abv','State_Code','Amount']  )
df2 = df2.groupby(['State_Abv','State_Code'])['Amount'].sum()

df2 = df2.reset_index()
# df2.head()

df3 = pd.DataFrame(data = df)
# res = df3.sort_values(['State_Abv'])
# df4 = pd.DataFrame(data = df3 )


df3 = df3.groupby(['State_Abv','State_Code','Damage_Descp'])['Amount'].sum()
# df4 = df4.groupby(['Damage_Descp'])

df3 = df3.reset_index()

states = alt.topo_feature(data.us_10m.url,'states')


on_hover = alt.selection_multi(fields=['State_Abv'])

df3['Amount'] = df3['Amount'] / 1000000



amount_map_states = alt.Chart(states).mark_geoshape(stroke='white').encode(
    color=alt.condition(on_hover, alt.Color('Amount:Q',scale=alt.Scale(scheme='blues')),alt.value('lightgray')),
    tooltip=['id:Q','Amount:Q']
).transform_lookup(
    lookup='id',
    from_=alt.LookupData(df2, 'State_Code', ['Amount','State_Abv'])
).project(
    type='albersUsa'
).add_selection(
    on_hover
).properties(
    width=600,
    height=400
)


bar_chart = alt.Chart(df3).mark_bar().encode(
    y=alt.Y('Damage_Descp:O', sort = '-x'),
    x=alt.X('sum(Amount):Q')
).transform_filter(on_hover).transform_lookup(lookup='State_Abv',from_=alt.LookupData(df3,'Sate_Abv'))


st.write(amount_map_states | bar_chart)





